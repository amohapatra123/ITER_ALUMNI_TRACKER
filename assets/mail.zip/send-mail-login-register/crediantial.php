<?php
define('EMAIL','shawondeveloper@gmail.com');
define('PASS','5215@87$');